import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.Period;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Marshaller;
import net.sf.saxon.BasicTransformerFactory;


public class Utilities {

	private static final Logger LOGGER = LogManager.getLogger();
	static String ConvertToXML(Fish tmp)
	{		
		LOGGER.info("ConvertToXML Has Started");
		StringWriter sw = new StringWriter();
		String xmlString = "";
		
		try {
			JAXBContext jaxbContext = JAXBContext.newInstance( tmp.getClass() );
			Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
			jaxbMarshaller.marshal(tmp, sw);
			
		} catch (JAXBException error) {
			LOGGER.error("JAXBException:" + error);
			error.printStackTrace();
		}

		xmlString = sw.toString();
		LOGGER.info("ConvertToXML Has Ended");
		return xmlString;
	}
	static String readFile(String path, Charset encoding) throws IOException

	{
		byte[] encoded = Files.readAllBytes(Paths.get(path));
		return new String(encoded, encoding);
	}
	
	static String XSLTTransform(String xml)
	{
		LOGGER.info("XSLTTransform Has Started");
		String XMLReturn = "";
		
		String content = null;
		try {
			content = Utilities.readFile("src/resources/SchoolOfApplicants.xml", StandardCharsets.US_ASCII);
		} catch (IOException e2) {
			e2.printStackTrace();
		}
		
		try {
			
			 StreamSource in        = new StreamSource(new StringReader(xml));
			 StreamSource trans     = new StreamSource(new StringReader(content));
			 StreamResult xmlOutput = new StreamResult(new StringWriter());

			 
			 BasicTransformerFactory factory = new BasicTransformerFactory();
			 Transformer t = factory.newTransformer(trans);
			 t.transform(in, xmlOutput);
					 					 
	         XMLReturn = xmlOutput.getWriter().toString();	     	

	      } catch (TransformerConfigurationException e) {
	    	  LOGGER.error("TransformerConfigurationException:" + e.toString());
	      } catch (TransformerException e) {
	    	  LOGGER.error("TransformerException:" + e.toString());
	      }
		LOGGER.info("XSLTTransform Has Ended");
		return XMLReturn;
	}
	
	static String FindNodeValue(String xpathQuery, Document document) throws XPathExpressionException
	{		
        //Create XPath        
        XPathFactory xpathfactory = XPathFactory.newInstance();
        XPath xpath = xpathfactory.newXPath();
        
		XPathExpression expr = xpath.compile(xpathQuery);
	    Object result = expr.evaluate(document, XPathConstants.NODESET);
	    NodeList nodes = (NodeList) result;
	    
		return nodes.getLength() != 0?nodes.item(0).getNodeValue():"";
		
	}
	static boolean isParsableAsInt(String input) {
	    try {
	        Integer.parseInt(input);
	        return true;
	    } catch (final NumberFormatException e) {
	    	LOGGER.error("NumberFormatException:"+ e.toString());
	        return false;
	    }
	}
	static boolean isParsableAsDouble(String input) {
	    try {
	        Double.parseDouble(input);
	        return true;
	    } catch (final NumberFormatException e) {
	    	LOGGER.error("NumberFormatException:"+ e.toString());
	        return false;
	    }
	}
	static boolean isParsableAsLocalDate(String input) {
	    try {
	    	LocalDate.parse(input);
	        return true;
	    } catch (final NumberFormatException e) {
	    	LOGGER.error("NumberFormatException:"+ e.toString());
	        return false;
	    }
	}
	
	static int calculateAge(LocalDate birthDate) {
	        if ((birthDate != null)) {
	            return Period.between(birthDate,  LocalDate.now()).getYears();
	        } else {
	            return 0;
	        }
	    }	
}
