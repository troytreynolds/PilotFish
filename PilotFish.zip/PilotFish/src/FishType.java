
public enum FishType {
	Shark,
	Ray,
	Eel,
	Herring,
	Salmon,
	Trout,
	Pike,
	Carp,
	Cat_Fish,
	Lantern,
	Cod,
	Flying_Fish,
	Squirrel_Fish,
	Pipe,
	Seahorse,
	Stonefish,
	Flat_Fish,
	Puffer,
	Perciforms
}
