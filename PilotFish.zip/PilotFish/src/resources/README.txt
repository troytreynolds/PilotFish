Author: Troy Reynolds 2022/06/21

Steps for this to work on local:
1. Under src/resources/config.properties -- You will need to change the connection properties for your database for this to work. 
2. Go into that database and deploy the sql script under src/resources/CreateTablePOLISEAHOLDERS.SQL
3. Make sure all the jar files under src/resources/jars are added as referenced libraries for the project. 

From here you should be able to run the code and see a new insert into the table you created. 

Assumptions Made: 
1. Middle name is not used in the XSLT due to there is no middle name in the database. 
2. Created _ in the enum for some of the fish names because there were spaces in the xml for them. _ were replaced with a space
   when the translation occured from xml to xslt. 
3. There would only be one address per Fish that the attribute home would be set to true. 
4. If the data was not there for the Fish some information would be sent to the database empty

Concerns with project: 
1. Database has no way to track inserts/updates and deletes. I know this was a sample project but just saying. Insert User,
   Insert datetime, Update user and Update datetime are imperative to have for tables like this. There is also no PK so duplicates can occur.

