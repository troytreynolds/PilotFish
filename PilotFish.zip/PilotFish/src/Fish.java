import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import jakarta.xml.bind.annotation.XmlRootElement;

//XMLRootElement is defined here for the creating of a class to an XML. You can find the function ConvertToXML in Utilities class that requires this.
//Remove this and those libraries will not know how to convert the class to an XML. 
@XmlRootElement
public class Fish {
	
	private String firstName = "";
	private String middleName = "";
	private String lastName = "";
	
	private Date dateOfBirth = new Date();
	
	private FishType classification;
	
	private List<FishAddress> addresses = new ArrayList<FishAddress>();

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public FishType getClassification() {
		return classification;
	}

	public void setClassification(FishType classification) {
		this.classification = classification;
	}

	public List<FishAddress> getAddresses() {
		return addresses;
	}

	public void setAddresses(List<FishAddress> addresses) {
		this.addresses = addresses;
	}
		
	public Fish( String firstName, String middleName, String lastName,Date dateOfBirth,FishType classification,List<FishAddress> addresses)
	{
		this.firstName = firstName;
		this.middleName = middleName;
		this.lastName = lastName;
		this.dateOfBirth = dateOfBirth;
		this.classification = classification;
		this.addresses = addresses;
		
	}
	public Fish()
	{		
		
	}
	
	
}
