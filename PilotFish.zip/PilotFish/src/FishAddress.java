
public class FishAddress {
	private String ocean = "";
	private String reef = "";
	
	private int depth;
	
	private boolean isHome;
	
	public String getOcean() {
		return ocean;
	}

	public void setOcean(String ocean) {
		this.ocean = ocean;
	}

	public String getReef() {
		return reef;
	}

	public void setReef(String reef) {
		this.reef = reef;
	}

	public int getDepth() {
		return depth;
	}

	public void setDepth(int depth) {
		this.depth = depth;
	}

	public boolean isHome() {
		return isHome;
	}

	public void setHome(boolean isHome) {
		this.isHome = isHome;
	}
	
	public FishAddress(String ocean,String reef,int depth,boolean isHome)
	{
		this.ocean = ocean;
		this.reef = reef;
		this.depth = depth;
		this.isHome = isHome;
	}
	public FishAddress()
	{
		
	}

}
