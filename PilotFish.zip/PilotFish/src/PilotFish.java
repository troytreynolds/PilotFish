import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.core.config.Configurator;
import org.xml.sax.SAXException;

public class PilotFish {

	
	private static final Logger LOGGER = LogManager.getLogger();
	
	public static void main(String args[]) throws SQLException, ParserConfigurationException, SAXException, IOException, XPathExpressionException 
	{
		Configurator.setAllLevels(LogManager.getRootLogger().getName(), Level.INFO);
		LOGGER.info("Main Has Started");
		//Creating an Address for a Fish
		FishAddress addressOne = new FishAddress("Pacific","Great Barrier Reef",31,false);
		
		//Creating a 2nd Address for a Fish
		FishAddress addressTwo = new FishAddress("Atlantic","Great Barrier Reef",32,true);
		
		//Adding the Addresses to a list. 
		List<FishAddress> addys = new ArrayList<FishAddress>();
		addys.add(addressOne);
		addys.add(addressTwo);
		
		//Creating an object of type fish. This is my sample one for testing.
		Fish sampleFish = new Fish("Troy","Tomas","Reynolds",new Date(),FishType.Squirrel_Fish,addys);
		
		//This will create an xml based on the Fish Object structure. 
		String xml = Utilities.ConvertToXML(sampleFish);
		
		//This will transform the xml above into a required layout xml. The XSLT for this can be viewed under the resources folder called SchoolOfApplicants.xml
		String transformedXML = Utilities.XSLTTransform(xml);
		
		//This will ingest the xml created from the XSLT and add the information into a database under table name POLISEAHOLDERS. 
		MYSqlConnection.SchoolOfApplicantsIngestion(transformedXML);		
		LOGGER.info("Main Has Ended");
	}

}
