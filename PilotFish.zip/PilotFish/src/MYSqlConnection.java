import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.StringReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Properties;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class MYSqlConnection {
	private static final Logger LOGGER = LogManager.getLogger();
	static Connection myConnection = null;

    static Connection GetConnection() throws SQLException
    {
    	LOGGER.info("GetConnection Started");
    	if (myConnection != null)
    	{
    		return myConnection;
    	}
    	
        String dbUrl ="";       // "jdbc:mysql://localhost:3306/database";
        String dbUsername ="";  // "root";
        String dbPassword = ""; //"mysql";
    	
    	String configFilePath = "src/resources/config.properties";
    	
    	//Gets all the db configurations from our property file. 
		try {
			FileInputStream propsInput = new FileInputStream(configFilePath);
			Properties prop = new Properties();
			prop.load(propsInput);
			
			dbUrl=prop.getProperty("DB_URL");
			dbUsername=prop.getProperty("DB_USER");
			dbPassword=prop.getProperty("DB_PSW");

		} catch (FileNotFoundException e) {
			LOGGER.error("FileNotFoundException:" + e.toString());
		} catch (IOException e) {	
			LOGGER.error("IOException:" + e.toString());
		}
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			LOGGER.error("ClassNotFoundException:" + e.toString());
		}
		LOGGER.info("GetConnection Ended");
        return DriverManager.getConnection(dbUrl, dbUsername, dbPassword);
    }
    
    static void SchoolOfApplicantsIngestion(String transformedXML) throws ParserConfigurationException, SAXException, IOException, XPathExpressionException, SQLException
    {
    	LOGGER.info("SchoolOfApplicantsIngestion Started");
    	String firstName = "";
    	String lastName = "";
    	String age = "";
    	String homeOcean = "";
    	String homeReef = "";
    	String homeDepthMeter = "";
    	
    	DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
        javax.xml.parsers.DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
        org.w3c.dom.Document document = docBuilder.parse(new InputSource(new StringReader(transformedXML)));
        
        //Xpath to fetch the number of fish in the XML. This will let us know how many fish we are adding per xml file. 
        String fishCountAsString = Utilities.FindNodeValue("/SchoolOfApplicants/Header/Records/text()", document);
        int fishCount = 0;
        
        //Want to make sure code does not break if we get an empty string for Records.
        if(Utilities.isParsableAsInt(fishCountAsString))
        {
        	fishCount = Integer.parseInt(fishCountAsString);
        }
        
        for(int i = 1; i <= fishCount; i++)  	
        {
        	//This first Xpath is looking for the name. If there is a space we are saying the first and last name was given. 
        	String NodeValue = Utilities.FindNodeValue("/SchoolOfApplicants/Fish[" + i + "]/Name/text()", document);
        	
        	//If there is a space we are saying that they are giving us their first and last name
        	if(NodeValue.contains(" "))
        	{
        		String[] Names = NodeValue.split(" ");
        		firstName = Names[0];
        		lastName = Names[1];
        	}
        	//If there is no space we are saying only the first name was given not the last
        	else
        	{
        		firstName = NodeValue;
        		lastName = "";		
        	}
        	
        	NodeValue = Utilities.FindNodeValue("/SchoolOfApplicants/Fish[" + i + "]/DOB/text()", document);
        	age = NodeValue;
        	//You see we are saying the attribute for Address needs to be true. We are saying that there is only one address per Fish and that is dictated by the attribute. 
        	NodeValue = Utilities.FindNodeValue("/SchoolOfApplicants/Fish[" + i + "]/Address[@home='true']/Ocean/text()", document);
        	homeOcean = NodeValue;
        	
        	NodeValue = Utilities.FindNodeValue("/SchoolOfApplicants/Fish[" + i + "]/Address[@home='true']/Reef/text()", document);
        	homeReef = NodeValue;
        	
        	NodeValue = Utilities.FindNodeValue("/SchoolOfApplicants/Fish[" + i + "]/Address[@home='true']/Depth/text()", document);
        	homeDepthMeter = NodeValue;
        	        	
        	int ageCalculated = 0;
        	
        	if(Utilities.isParsableAsLocalDate(age))
        	{
        		 ageCalculated = Utilities.calculateAge(LocalDate.parse(age));
        	}
        	
        	InsertRowIntoDatabase(firstName,lastName,ageCalculated,homeOcean,homeReef,homeDepthMeter);            	
        	} 
        LOGGER.info("SchoolOfApplicantsIngestion Ended With " + fishCountAsString + " Inserts");
       
    }

    static void InsertRowIntoDatabase(String firstName, String lastName,int age,String homeOcean,String homeReef,String homeDepthMeter) throws SQLException
    {
    	LOGGER.info("InsertRowIntoDatabase Started");
    	//This is to ensure we have a connection. 
    	if (myConnection == null ||  myConnection.isClosed())
    	{
    		myConnection = MYSqlConnection.GetConnection();
    	}
    	
    	double homeDepthMeterAsDouble = 0;
    	
    	if(Utilities.isParsableAsDouble(homeDepthMeter))
    	{
    		homeDepthMeterAsDouble = Double.parseDouble(homeDepthMeter);
    	}
    	String sql = " insert into POLISEAHOLDERS (FNAME, LNAME, AGE, HOME_OCEAN, HOME_REEF,HOME_DEPTH_METERS)"
    		    + " values (?, ?, ?, ?, ?,?)";
    	try {
    	  PreparedStatement preparedStmt = myConnection.prepareStatement(sql);
    	  preparedStmt.setString (1, firstName);
    	  preparedStmt.setString (2, lastName);
    	  preparedStmt.setInt   (3, age);
    	  preparedStmt.setString(4, homeOcean);
    	  preparedStmt.setString(5, homeReef);
    	  preparedStmt.setDouble(6, homeDepthMeterAsDouble);
    	  
    	  preparedStmt.execute();
    	}
    	  catch (Exception e)
    	  {
    		  LOGGER.error("Exception:" + e.toString());
    	  }
    	
    	LOGGER.info("InsertRowIntoDatabase Ended");
    	
    }
        
    	    	    	  
}
